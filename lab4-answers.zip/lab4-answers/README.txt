1) All source code software in this zip file is distributed under the General Public License. 
By amending, modifying or using this software, you indicate your acceptance of
this License.

2) JAR files in the "lib" folder are released under their respective licenses.

Copies of all these licenses are available in the "licenses" folder.


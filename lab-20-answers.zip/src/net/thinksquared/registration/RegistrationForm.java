package net.thinksquared.registration;

/****************************************************
* ActionForm subclass for the Registration webapp.
*
* Copyright 2005 by Arnold Doray
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************/


import javax.servlet.http.*;
import org.apache.struts.action.*;

public final class RegistrationForm extends ActionForm{
        
        private final int MIN_USERID_LENGTH = 5;
        private final int MAX_USERID_LENGTH = 15;

        private final int MIN_PWD_LENGTH = 8;
        private final int MAX_PWD_LENGTH = 20;

        private String _userid = null;
        private String _pwd = null;
        private String _pwd2 = null;


        public String getUserid(){ return _userid; }
        public void   setUserid(String userid){ _userid = userid; }

        public String getPassword(){ return _pwd; }
        public void   setPassword(String pwd){ _pwd = pwd; }

        public String getPassword2(){ return _pwd2; }
        public void   setPassword2(String pwd2){ _pwd2 = pwd2; }

    
        public void reset(ActionMapping mapping, 
                          HttpServletRequest request){

            _userid = _pwd = _pwd2 = null;

        }

        public ActionErrors validate(ActionMapping mapping, 
                                     HttpServletRequest request){

        
            ActionErrors errors = new ActionErrors();   
            
            if( _userid == null ){
                errors.add("userid", new ActionMessage("registration.error.userid.missing"));

            }else if( _userid.length() < MIN_USERID_LENGTH ){
                errors.add("userid", new ActionMessage("registration.error.userid.short"));

            }else if( _userid.length() > MAX_USERID_LENGTH ){
                errors.add("userid", new ActionMessage("registration.error.userid.long"));

            }else if( !_pwd.equals(_pwd2)){
                errors.add("password", new ActionMessage("registration.error.password.mismatch"));

            }else if( _pwd.length() < MIN_PWD_LENGTH ){
                errors.add("password", new ActionMessage("registration.error.password.short"));

            }else if( _pwd.length() > MAX_PWD_LENGTH ){
                errors.add("password", new ActionMessage("registration.error.password.long"));

            }

            return errors;

        }

}



package net.thinksquared.registration;

/****************************************************
* A dummy database for the Registration webapp.
*
* Copyright 2005 by Arnold Doray
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************/

import java.util.HashMap;

public class DummyRegistrationModel implements RegistrationModel{

	private String _userid = null;

	private static HashMap dbase = new HashMap();	

	public int save(String userid, String pwd){

	    try{	

    		//critical section:
    		synchronized(dbase){
    
    		  if(dbase.containsKey(userid)) return ERROR_USER_EXISTS;
    
    		  dbase.put(userid,pwd);
    		  _userid = userid; 
    		  return OK;			
    	   	}

	    }catch(Exception e){
		  return ERROR_UNKNOWN;
	    }
	    	
	}

	public String getUserid(){ return _userid; }
}

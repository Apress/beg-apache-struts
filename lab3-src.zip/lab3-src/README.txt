1) All source code software in this zip file is distributed under the General Public License. 
By amending, modifying or using this software, you indicate your acceptance of
this License.
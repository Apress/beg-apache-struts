package net.thinksquared.bookstore.database;

/********************************************************************
    Copyright (C) 2005  Arnold Doray

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*********************************************************************/


public class Test{


    //NOTE! If you run this Test more than once, remember that
    //      you will create duplicate authors, books and publishers
    //      It is advisable to delete and re-create the database
    //      each time you run Test, to avoid confusion. -AD

    public static void main(String[] args) throws Exception{

        /* Create some authors, books and publishers */

        Author lc = new Author();
        lc.setFirstName("Lewis");
        lc.setLastName("Caroll");
        lc.setFullName("Lewis Caroll");
        lc.save();

        Author he = new Author();
        he.setFirstName("Harold");
        he.setLastName("Edwards");
        he.setFullName("Harold Edwards");
        he.save();

        Author acd = new Author();
        acd.setFirstName("Arthur");
        acd.setLastName("Doyle");
        acd.setFullName("Arthur Conan Doyle");
        acd.save();

        Publisher dover = new Publisher();
        dover.setName("Dover Books");
        dover.save();

        Publisher mac = new Publisher();
        mac.setName("Macmillian Publishers");
        mac.save();

        Book alice = new Book();
        alice.setAuthor(lc);
        alice.setPublisher(dover);
        alice.setTitle("Alice In Wonderland");
        alice.setISBN("ISBN0000001");
        alice.save();

        Book rzf = new Book();
        rzf.setAuthor(he);
        rzf.setPublisher(dover);
        rzf.setTitle("Riemanns Zeta Function");
        rzf.setISBN("ISBN0000002");
        rzf.save();

        Book shc = new Book();
        shc.setAuthor(acd);
        shc.setPublisher(mac);
        shc.setTitle("The Sherlock Holmes Casebook");
        shc.setISBN("ISBN0000003");
        shc.save();

        Book ttlg = new Book();
        ttlg.setAuthor(lc);
        ttlg.setPublisher(mac);
        ttlg.setTitle("Through the Looking Glass");
        ttlg.setISBN("ISBN0000004");
        ttlg.save();


        /* retrieve the data */

        //List all authors and their books from Dover

        System.out.println("Books from Dover Books:"); 
        Criteria crit = new Criteria();
                 crit.add(Book.PUBLISHER_ID,dover.getPublisherId());        
        for(Scroller books = BookPeer.doSelect(crit); books.hasNext();){
          Book book = (Book)books.next(); 
          System.out.print(book.getTitle());
          System.out.print(" by ");
          Author author = book.getAuthor();
          if(author != null){
            System.out.println(author.getFullName());
          }else{
            System.out.println("-- no author in databse --");    
          }
        }


        //List all publishers who carry books by Lewis Caroll  
     
        System.out.println("Publishers who carry Lewis Caroll:"); 
        crit = new Criteria();
        crit.addJoin(Publisher.PUBLISHER_ID,Book.PUBLISHER_ID); 
        crit.add(Book.AUTHOR_ID,lc.getAuthorId());       
        for(Scroller publishers = PublisherPeer.doSelect(crit); publishers.hasNext();){
          Publisher publisher = (Publisher)publishers.next(); 
          System.out.println(publisher.getName());
        }        

    }

}


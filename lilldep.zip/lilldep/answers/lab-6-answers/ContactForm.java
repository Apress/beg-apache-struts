package net.thinksquared.lilldep.struts;

/*******************************************************
* Form for data entry
* author: Arnold Doray
* date: 19 Mar 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
********************************************************/

import javax.servlet.http.*;
import org.apache.struts.action.*;
import net.thinksquared.lilldep.database.*;

public class ContactForm extends ActionForm{       

        protected Contact _contact;

        public ContactForm(){
            _contact = new Contact();
        }        
        
        /* 14 + 1 getters and setters */ 

        public String getName(){ return _contact.getName(); }
        public void   setName(String name){_contact.setName(name); }
        public String getDesignation(){ return _contact.getDesignation(); }
        public void   setDesignation(String designation){ _contact.setDesignation(designation); }
        public String getDepartment(){ return _contact.getDepartment(); }
        public void   setDepartment(String department){ _contact.setDepartment(department); }
        public String getCompany(){ return _contact.getCompany(); }
        public void   setCompany(String company){_contact.setCompany(company); }
        public String getAddress(){ return _contact.getAddress(); }
        public void   setAddress(String address){ _contact.setAddress(address); }
        public String getPostcode(){ return _contact.getPostcode(); }
        public void   setPostcode(String postcode){ _contact.setPostcode(postcode); }
        public String getCountry(){ return _contact.getCountry(); }
        public void   setCountry(String country){ _contact.setCountry(country); }
        public String getEmail(){ return _contact.getEmail(); }
        public void   setEmail(String email){ _contact.setEmail(email); }
        public String getWebsite(){ return _contact.getWebsite(); }
        public void   setWebsite(String website){ _contact.setWebsite(website); }
        public String getTel(){ return _contact.getTel(); }
        public void   setTel(String tel){ _contact.setTel(tel); }
        public String getFax(){ return _contact.getFax(); }
        public void   setFax(String fax){ _contact.setFax(fax); }
        public String getActivity(){ return _contact.getActivity(); }
        public void   setActivity(String activity){ _contact.setActivity(activity); }
        public String getClassification(){ return _contact.getClassification(); }
        public void   setClassification(String classification){ _contact.setClassification(classification); }
        public String getMemo(){ return _contact.getMemo(); }
        public void   setMemo(String memo){ _contact.setMemo(memo); }
    

        public Contact getContact(){ return _contact; }
        public void setContact(Contact contact){ _contact = contact; }
   

        public ActionErrors validate(ActionMapping mapping, 
                                     HttpServletRequest request){

            ActionErrors errors = new ActionErrors();  

            //NO BLANK COMPANY NAME
            if(_contact.getCompany().trim().length() == 0){
                errors.add("company", new ActionMessage("lilldep.error.company"));
            }

            //NO BLANK NAME
            if(_contact.getName().trim().length() == 0){
                errors.add("name", new ActionMessage("lilldep.error.name"));
            }
 
            //CHECK EMAIL (badly implemented! -- see chapter on Validator Framework for better solution)
            if(_contact.getEmail().length() > 0 && _contact.getEmail().indexOf('@') == -1){  
                    errors.add("email", new ActionMessage("lilldep.error.email"));    
            }
            
            return errors;
            
        }


        public void reset(ActionMapping mapping, 
                          HttpServletRequest request){   
             
            _contact.clear();

        }

}



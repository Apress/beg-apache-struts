package net.thinksquared.lilldep.struts;

/*******************************************************
* Adds selected contacts from a given Collection
* author: Arnold Doray
* date: 19 Mar 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
********************************************************/

import javax.servlet.http.*;
import org.apache.struts.action.*;

import net.thinksquared.lilldep.database.*;

public final class AddCollectionContactsAction extends Action implements JSPConstants{


    public ActionForward execute(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
    throws Exception{
 

        //get the Collection
        Collection collection = (Collection) request.getSession().getAttribute(COLLECTION);

        DynaActionForm dForm =  (DynaActionForm) form;

        Criteria crit = new Criteria();

        try{

            for(int i = 0; true ; i++){

                int contactId = Integer.parseInt((String) dForm.get("selected",i));

                crit.clear();

                /** This condition alone means that a contact 
                 *  can only belong to ONE collection. 
                 *  To allow a single Contact to belong to more
                 *  than one collection, you'd add:
                 *  crit.add(CollectionMap.COLLECTION_ID,collection.getCollectionId());
                 *  in addition to the condition below:
                 **/
                crit.add(CollectionMap.CONTACT_ID,contactId);

                if(!CollectionMapPeer.doSelect(crit).hasNext()){
                    CollectionMap cm = new CollectionMap();
                    cm.setContactId(contactId);
                    cm.setCollection(collection);
                    cm.save();
                }
               
            }

        }catch(IndexOutOfBoundsException ignore){}

        return mapping.findForward("success");

        
    }

}



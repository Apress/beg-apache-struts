package net.thinksquared.lilldep.struts;

/*******************************************************
* Navigates to a collection
* author: Arnold Doray
* date: 19 Mar 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
********************************************************/

import javax.servlet.http.*;
import org.apache.struts.action.*;
import org.apache.struts.actions.*;
import net.thinksquared.lilldep.database.*;

public final class CollectionNavAction extends DispatchAction implements JSPConstants{


    public ActionForward go(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response)
    throws Exception{

        //get the contact id
        int contactId = Integer.parseInt(request.getParameter(ID));

        //save the contact's offset onto the session
        request.getSession().setAttribute(OFFSET,request.getParameter(OFFSET));

        //get the Contact
        Criteria crit = new Criteria();
        crit.add(Contact.CONTACT_ID,contactId);
        Scroller s = ContactPeer.doSelect(crit);
        if(s.hasNext()){
            
            ContactForm cForm = (ContactForm) form;
            cForm.setContact((Contact) s.next());
            return mapping.findForward("success");

        }else{

            return mapping.getInputForward();
        }
        
    }

    public ActionForward next(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response){

        return moveTo(mapping,form,request,1);


    }

    public ActionForward previous(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 HttpServletResponse response){

        return moveTo(mapping,form,request,-1);

    }

    protected int getOffset(HttpServletRequest request){
        return Integer.parseInt((String)request.getSession().getAttribute(OFFSET));
    }

    protected void setOffset(HttpServletRequest request, int offset){
        request.getSession().setAttribute(OFFSET,"" + offset);
    }

    protected ActionForward moveTo(ActionMapping mapping,
                                 ActionForm form,
                                 HttpServletRequest request,
                                 int step){

        try{

            //get the current Collection
            Collection collection = (Collection)request.getSession().getAttribute(COLLECTION);

            //get the Contacts on this Collection
            Scroller s = collection.getContacts();

            //get the offset
            int offset = step + getOffset(request);

            //move to the right location
            if(offset > 0){
                s.absolute(offset);
            }else{
                offset = 0; //to prevent saving negative offsets.
            }

            if(s.hasNext()){
    
                //get the contact and place it on the form
                ContactForm cForm = (ContactForm) form;
                cForm.setContact((Contact) s.next()); 

                //save the new offset
                setOffset(request,offset); 

                return mapping.findForward("success");
            }
            
        }catch(Exception ignore){}

        return mapping.getInputForward();

    }   

}



package net.thinksquared.lilldep.struts;

/*******************************************************
* Form for data entry
* author: Arnold Doray
* date: 19 Mar 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
********************************************************/



import javax.servlet.http.*;
import org.apache.struts.action.*;
import org.apache.struts.validator.ValidatorForm;
import net.thinksquared.lilldep.database.*;

public class ContactForm extends ValidatorForm{       

        protected Contact _contact;

        public ContactForm(){
            _contact = new Contact();
        }        
        
        /* removed 14 getters and setters */     

        public Contact getContact(){ return _contact; }
        public void setContact(Contact contact){ _contact = contact; }
   
        /** VALIDATIONS MOVED TO VALIDATOR FRAMEWORK !

        public ActionErrors validate(ActionMapping mapping, 
                                     HttpServletRequest request){

            ActionErrors errors = new ActionErrors();  

            //NO BLANK COMPANY NAME
            if(_contact.getCompany().trim().length() == 0){
                errors.add("company", new ActionMessage("lilldep.error.company"));
            }

            //NO BLANK NAME
            if(_contact.getName().trim().length() == 0){
                errors.add("name", new ActionMessage("lilldep.error.name"));
            }
 
            //CHECK EMAIL (badly implemented! -- see chapter on Validator Framework for better solution)
            if(_contact.getEmail().length() > 0 && _contact.getEmail().indexOf('@') == -1){  
                    errors.add("email", new ActionMessage("lilldep.error.email"));    
            }
            
            return errors;
            
        }

        **/


        public void reset(ActionMapping mapping, 
                          HttpServletRequest request){   
             
            _contact.clear();

        }

}



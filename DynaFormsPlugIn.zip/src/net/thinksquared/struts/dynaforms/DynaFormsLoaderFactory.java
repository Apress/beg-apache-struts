package net.thinksquared.struts.dynaforms;

/*******************************************************
* The factory for loaders. It checks the "type" attribute
* of <code>&lt;form-beans&gt;</code> for an alternative loader.
*
* date: 20 Sept 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
*   This library is free software; you can redistribute it and/or
*   modify it under the terms of the GNU Lesser General Public
*   License as published by the Free Software Foundation; either
*   version 2.1 of the License, or (at your option) any later version.
*
*   This library is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*   Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public
*   License along with this library; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*
********************************************************/


import java.io.IOException;
import java.io.File;
import org.apache.commons.digester.Digester;
import net.thinksquared.struts.dynaforms.definitions.Beans;

public class DynaFormsLoaderFactory{

    private DynaFormsLoaderFactory(){}

    public static DynaFormsLoader getLoader(String filename)
    throws IOException,DefinitionsException,NoSuitableLoaderException{


        Beans config = readConfig(filename);

        String clazzname = config.getType();

        if( null == clazzname ){

            return new DefaultDynaFormsLoader();

        }else{
            try{                                
                return (DynaFormsLoader) instantiate(clazzname);                       
            }catch(Exception e){
                throw new NoSuitableLoaderException("Can't initialize loader " + 
                                                     clazzname);
            }             
        }
    }

    protected static Beans readConfig(String filename)
    throws IOException,DefinitionsException{

        try{

            Digester digester = new Digester();
            digester.addObjectCreate("form-beans", 
                                     "net.thinksquared.struts.dynaforms.definitions.Beans");
            digester.addSetProperties("form-beans");
            return (Beans)digester.parse(new File(filename));

        }catch(IOException ioe){
            throw ioe;
        }catch(Exception e){
            throw new DefinitionsException("Definitions file " + 
                                            filename + 
                                           " has incorrect format");
        }

    }

    protected static Object instantiate(String clazzname)
    throws Exception{
        return Class.forName(clazzname).newInstance();
    }

}


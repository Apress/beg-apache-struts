package net.thinksquared.struts.dynaforms;

/*******************************************************
* Default implementation of DynaFormsLoader
*
* date: 20 Sept 2005
* version: 0.0
*
* Copyright 2005 Arnold Doray   
*
*   This library is free software; you can redistribute it and/or
*   modify it under the terms of the GNU Lesser General Public
*   License as published by the Free Software Foundation; either
*   version 2.1 of the License, or (at your option) any later version.
*
*   This library is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*   Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public
*   License along with this library; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*
********************************************************/

import java.io.IOException;
import java.io.File;
import java.util.Iterator;

import org.apache.struts.config.ModuleConfig;
import org.apache.struts.config.FormBeanConfig;
import org.apache.struts.config.FormPropertyConfig;
import org.apache.commons.digester.Digester;

import net.thinksquared.struts.dynaforms.*;
import net.thinksquared.struts.dynaforms.definitions.*;

public class DefaultDynaFormsLoader implements DynaFormsLoader{

    public void load(String filename,ModuleConfig config)
    throws IOException, DefinitionsException{

        Beans beans = readBeans(filename);

        for(Iterator beanz = beans.values().iterator(); beanz.hasNext();){
            Bean b = resolve(beans, (Bean)beanz.next());
            if(b.getCreate()){
                config.addFormBeanConfig(createFormBeanConfig(b));
            }
        }

    }


    protected Beans readBeans(String filename)
    throws IOException, DefinitionsException{
        try{

            Digester digester = new Digester();
            digester.addObjectCreate("form-beans", 
                                     "net.thinksquared.struts.dynaforms.definitions.Beans");
            digester.addSetProperties("form-beans");
            
            digester.addObjectCreate("form-beans/form-bean", 
                                     "net.thinksquared.struts.dynaforms.definitions.Bean");
            digester.addSetProperties("form-beans/form-bean");

            digester.addObjectCreate("form-beans/form-bean/form-property", 
                                     "net.thinksquared.struts.dynaforms.definitions.Property");
            digester.addSetProperties("form-beans/form-bean/form-property");            
            digester.addSetNext("form-beans/form-bean/form-property","addProperty");

            digester.addSetNext("form-beans/form-bean","addBean");    

            return (Beans)digester.parse(new File(filename));

        }catch(IOException ioe){
            throw ioe;
        }catch(Exception e){
            throw new DefinitionsException("Definitions file " + 
                                            filename + 
                                           " has incorrect format.");
        }
    }

    protected Bean resolve(Beans beans, Bean b)
    throws DefinitionsException{

        if(b.getExtends() == null){

            //check that all properties have types
            Object[] properties = b.values().toArray();                    
            for(int i = 0; i < properties.length; i++){
                Property p = (Property) properties[i];
                if(p.getType() == null){

                    throw new DefinitionsException("Type of property '" +
                                                   p.getName() +
                                                   "' has not been set on form bean '" +   
                                                   b.getName() +
                                                   "'");
                }
            }
            return b;
        }

        Bean parent = beans.getBean(b.getExtends());
        if(parent == null){
            throw new DefinitionsException("Can't resolve parent bean named " +
                                            b.getExtends()); 
        }

        b.merge(parent);
    
        //resolve this bean further up the hierarchy
        return resolve(beans,b);                                    
    }


    protected FormBeanConfig createFormBeanConfig(Bean bean){

        FormBeanConfig config = bean.getFormBeanConfig();
        
        //add in all the form-properties for this form-bean
        for(Iterator ps = bean.values().iterator(); ps.hasNext();){
            Property p = (Property) ps.next();
            config.addFormPropertyConfig(p.getFormPropertyConfig());                
        }

        // Force creation and registration of DynaActionFormClass instances
        // for all dynamic form beans
        if(config.getDynamic()){
            config.getDynaActionFormClass();
        }

        return config;
    
    }


}
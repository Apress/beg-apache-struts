package net.thinksquared.struts.dynaforms.definitions;

/*******************************************************
* JavaBean to hold <code>&lt;form-bean&gt;</code> information. 
* <code>&lt;set-property&gt;</code> not supported.
*
* date: 20 Sept 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
*   This library is free software; you can redistribute it and/or
*   modify it under the terms of the GNU Lesser General Public
*   License as published by the Free Software Foundation; either
*   version 2.1 of the License, or (at your option) any later version.
*
*   This library is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*   Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public
*   License along with this library; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*
********************************************************/


import java.util.*;
import org.apache.struts.config.FormBeanConfig;

public class Bean extends HashMap{

    protected String _name = null;
    protected String _type = null;
    protected String _extends = null;
    protected boolean _create = true;


    public void addProperty(Property p){
        put(p.getName(),p);
    }

    public Property getProperty(String name){
        Object obj = get(name);
        return (obj == null)? null : (Property)obj;
    }

    public void setName(String n){
        _name = n;
    }

    public String getName(){
        return _name;
    }

    public void setType(String t){
        _type = t;
    }

    public String getType(){
        return _type;
    }

    public void setExtends(String e){
        _extends = e;
    }

    public String getExtends(){
        return _extends;
    }

    public void setCreate(boolean b){
        _create = b;
    }

    public boolean getCreate(){
        return _create;
    }


    /**
    * Merges a bean with its parent.
    * if the bean b is not a parent, then
    * the merging is NOT done.
    */    
    public void merge(Bean b){

        //don't merge if there is no common properties between the beans.
        if(_extends == null || !_extends.equals(b.getName())) return;

        _extends = b.getExtends();

        if(_type == null){
            _type = b.getType();
        }

        Object[] properties = b.values().toArray();        
        
        for(int i = 0; i < properties.length; i++){
            Property p = (Property) properties[i];
            Object obj = getProperty(p.getName());
            if(obj == null){
                addProperty(p);
            }else{
                Property cp = (Property) obj;
                if(cp.getType() == null){
                    cp.setType(p.getType());
                }  
            }
        }

    }

    /**
    * Gets the FormBeanConfig instance
    * that this Bean represents
    */        
    public FormBeanConfig getFormBeanConfig(){

        FormBeanConfig config = new FormBeanConfig();
        config.setName(getName());
        config.setType(getType());
            
        return config;
    }


    public String toString(){
        StringBuffer ret = new StringBuffer();
        ret.append("bean (name= " + _name + " type=" + _type + " extends=" + _extends);
        Object[] properties = values().toArray();        
        for(int i = 0; i < properties.length ; i++){
            ret.append("\n");
            ret.append((Property) properties[i]);            
        }    
        return ret.toString();
    }


}
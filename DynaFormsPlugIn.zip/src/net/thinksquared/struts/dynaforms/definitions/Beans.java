package net.thinksquared.struts.dynaforms.definitions;

/*******************************************************
* JavaBean to hold <code>&lt;form-beans&gt;</code> information. 
* <code>&lt;set-property&gt;</code> not supported.
* date: 20 Sept 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
*   This library is free software; you can redistribute it and/or
*   modify it under the terms of the GNU Lesser General Public
*   License as published by the Free Software Foundation; either
*   version 2.1 of the License, or (at your option) any later version.
*
*   This library is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*   Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public
*   License along with this library; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*
********************************************************/


import java.util.*;

public class Beans extends HashMap{

    protected String _type = null;     //Loader classname

    public void addBean(Bean b){
        put(b.getName(),b);
    }

    public Bean getBean(String name){
        Object obj = get(name);
        return (obj == null)? null : (Bean)obj;
    }

    public void setType(String t){
        _type = t;
    }

    public String getType(){
        return _type;
    }

    public String toString(){
        StringBuffer ret = new StringBuffer();
        ret.append("beans (type= " + _type);
        Object[] beans = values().toArray();
        for(int i = 0; i < size() ; i++){
            ret.append("\n");
            ret.append((Bean) beans[i]);            
        }    
        return ret.toString();
    }


}
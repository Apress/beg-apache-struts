package net.thinksquared.struts.dynaforms.definitions;

/*******************************************************
* JavaBean to hold <code>&lt;form-property&gt;</code> information. 
* <code>&lt;set-property&gt;</code> not supported.
* date: 20 Sept 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
*   This library is free software; you can redistribute it and/or
*   modify it under the terms of the GNU Lesser General Public
*   License as published by the Free Software Foundation; either
*   version 2.1 of the License, or (at your option) any later version.
*
*   This library is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*   Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public
*   License along with this library; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*
********************************************************/


import org.apache.struts.config.FormPropertyConfig;

public class Property{

    protected String _name = null;
    protected String _type = null;
    protected String _initial = null;
    protected int    _size = 0;

    public void setName(String n){
        _name = n;
    }

    public String getName(){
        return _name;
    }

    public void setType(String t){
        _type = t;
    }

    public String getType(){
        return _type;
    }

    public void setInitial(String i){
        _initial = i;
    }

    public String getInitial(){
        return _initial;
    }

    public void setSize(int s){
        _size = s;
    }

    public int getSize(){
        return _size;
    }

    /**
    * Gets the FormPropertyConfig instance
    * that this Property represents
    */        
    public FormPropertyConfig getFormPropertyConfig(){

        return new FormPropertyConfig(getName(), 
                                      getType(),
                                      getInitial(),
                                      getSize());
    }

    public String toString(){
        StringBuffer ret = new StringBuffer();
        ret.append("property\n");
        ret.append("\tname=" + _name + "\n");
        ret.append("\ttype=" + _type + "\n");
        ret.append("\tinitial=" + _initial + "\n");
        ret.append("\tsize=" + _size + "\n");
        return ret.toString();
    }

}
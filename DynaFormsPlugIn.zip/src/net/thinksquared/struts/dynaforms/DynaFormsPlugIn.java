package net.thinksquared.struts.dynaforms;

/*******************************************************
* Plugin for DynaForms.
*
* date: 20 Sept 2005
* version: 0.0
* Copyright 2005 Arnold Doray   
*
*   This library is free software; you can redistribute it and/or
*   modify it under the terms of the GNU Lesser General Public
*   License as published by the Free Software Foundation; either
*   version 2.1 of the License, or (at your option) any later version.
*
*   This library is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
*   Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public
*   License along with this library; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*
*
********************************************************/


import java.io.IOException;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.struts.action.PlugIn;
import org.apache.struts.action.ActionServlet;
import org.apache.struts.config.ModuleConfig;


public class DynaFormsPlugIn implements PlugIn{    

    protected String _pathnames = "";

    public void setPathnames(String pathnames){
        _pathnames = pathnames;
    }

    public void init(ActionServlet servlet, ModuleConfig config)
    throws ServletException{

        ServletContext context = servlet.getServletContext();
        
        StringTokenizer tokenizer = new StringTokenizer(_pathnames,",");        
        while(tokenizer.hasMoreTokens()){

            String fname = context.getRealPath(tokenizer.nextToken().trim());

            try{                 
                DynaFormsLoader loader = DynaFormsLoaderFactory.getLoader(fname);
                loader.load(fname,config);

            }catch(NoSuitableLoaderException le){
                throw new ServletException(le);
            }catch(IOException ioe){
                throw new ServletException(ioe);
            }catch(DefinitionsException de){
                throw new ServletException(de);
            }
        }        

    }

    public void destroy(){/* do nothing */}
   
}


package net.thinksquared.reg;

/**************************************************************
    Copyright (C) 2005  Arnold Doray

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

**************************************************************/


import java.util.Map;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.text.MessageFormat;

import javax.faces.context.FacesContext;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;

import java.util.*;

public class User { 

    private static Map _dbase = new HashMap(); //our dummy database.

    private String _uid,_pwd;

    private UIComponent _container;

    public User(){
        _uid = null;
        _pwd = null;
        _container = null;
    }

    //------------------------------------- data get/set

	public void setUserId(String uid){ 
		_uid = uid;
	} 

	public String getUserId(){ 
		return _uid;
	}

	public void setPassword(String pwd){ 
		_pwd = pwd;
    } 

	public String getPassword(){ 
		return _pwd;
  }   

    //------------------------------------- container get/set

    public void setContainer(UIComponent container){
        System.out.println("Setting.." + container);
        _container = container;
    }
    public UIComponent getContainer(){
        //very important to return null,
        //otherwise, previous UI tree fragment will
        //be grafted in!
        return null;
    }

    //------------------------------------- Actions

    public String Register(){
        
        //get a handle to the current "context"
        FacesContext context = FacesContext.getCurrentInstance();

        //get a handle to the desired properties file
        ResourceBundle bundle =
                ResourceBundle.getBundle("net.thinksquared.reg.messages",
                    		context.getViewRoot().getLocale());

        //complex validation: user exists?    
        if(_dbase.get(_uid) != null){

            Object[] params = {_uid};
            String msg = MessageFormat.format(
                bundle.getString("user_exists"),params);

            String clientId = _container.findComponent("userId").getClientId(context);
            context.addMessage(clientId, new FacesMessage(msg)); 

            //returning null causes input page to be re-displayed
            return null; 
        }

        //everything OK - go ahead and register the user    
        _dbase.put(_uid,_pwd); 

        Object[] params = {_uid,_pwd};
        String msg = MessageFormat.format(
                bundle.getString("registered_ok"),params);
        context.addMessage (null, new FacesMessage(msg)); 

        return "success";      
    }

    public String Logon(){

        //get a handle to the current "context"
        FacesContext context = FacesContext.getCurrentInstance();

        //get a handle to the desired properties file
        ResourceBundle bundle =
                ResourceBundle.getBundle("net.thinksquared.reg.messages",
                    		context.getViewRoot().getLocale());

        //complex validations: 
        //  does the user exist?
        //  does the given pwd match the one in database?  
        Object pwd = _dbase.get(_uid);  
        if(null == pwd){

            String msg = bundle.getString("user_not_registered");
            context.addMessage (null, new FacesMessage(msg)); 

            return "register"; 

        }else if(!pwd.equals(_pwd)){
  
            String msg = bundle.getString("wrong_password");
            String clientId = _container.findComponent("password").getClientId(context);
            context.addMessage(clientId, new FacesMessage(msg)); 

            return null; 
        }

        //everything OK - go ahead and log in the user    
        //code to log on user here...
        Object[] params = {_uid};
        String msg = MessageFormat.format(
                bundle.getString("logon_ok"),params);
        context.addMessage (null, new FacesMessage(msg)); 

        return "success";
    }
}
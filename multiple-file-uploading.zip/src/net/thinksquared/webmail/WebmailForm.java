package net.thinksquared.webmail;

/*****************************************************
* Copyright 2005 by Arnold Doray
*
*   This program is free software; you can redistribute it and/or modify
*   it under the terms of the GNU General Public License as published by
*   the Free Software Foundation; either version 2 of the License, or
*   (at your option) any later version.
*
*   This program is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU General Public License for more details.
*
*   You should have received a copy of the GNU General Public License
*   along with this program; if not, write to the Free Software
*   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************/

import javax.servlet.http.*;
import org.apache.struts.action.*;

public class WebmailForm extends FileUploadForm{ 

   private String _recipients;
   private String _subject;
   private String _message;

   public String getRecipients(){
      return _recipients;
   }

   public String getSubject(){
      return _subject;
   }

   public String getMessage(){
      return _message;
   }

   public void setRecipients(String recipients){
      _recipients = recipients;
   }

   public void setSubject(String subject){
      _subject = subject;
   }

   public void setMessage(String message){
      _message = message;
   }

   public ActionErrors validate(ActionMapping mapping, 
                                HttpServletRequest request){

      ActionErrors errors = new ActionErrors();  

      //NO BLANK MESSAGES/RECIPIENTS/SUBJECTS
      if(_recipients.trim().length() == 0){
        errors.add("recipients", new ActionMessage("webmail.error.recipients"));
      }
      if(_subject.trim().length() == 0){
        errors.add("subject", new ActionMessage("webmail.error.subject"));
      }
      if(_message.trim().length() == 0){
        errors.add("message", new ActionMessage("webmail.error.message"));
      }
            
      return errors;
   }

}